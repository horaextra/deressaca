#Database file
db = DAL("sqlite://ressaca.db")

db.define_table('hangover',
    Field('counter', 'integer', required=True)
)
