def index():
    counter = len(db().select(db.hangover.ALL))
    template_counter = str(counter)
    template_counter = '0' * (4 - len(template_counter)) + template_counter
    return {
        'counter': counter,
        'template_counter': template_counter,
    }

def im_hungover():
    hangover_rows = db().select(
        db.hangover.counter,
        orderby=~db.hangover.id,
        limitby=(0,1)
    )

    if hangover_rows:
        current_hangovers = hangover_rows[0].counter + 1
    else:
        current_hangovers = 1

    db.hangover.insert(counter=current_hangovers)
    redirect('/')
