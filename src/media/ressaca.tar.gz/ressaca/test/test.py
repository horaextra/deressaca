import unittest

from gluon.globals import Request, Response

execfile("applications/ressaca/controllers/main.py", globals())

class TestCounter(unittest.TestCase):

    def setUp(self):
        request = Request()
        response = Response()
        db.hangover.truncate()

    def test_counter_is_zero_when_there_is_no_hangover(self):
        index_response = index()
        self.assertEquals(0, index_response['counter'])

    def test_post_inc_counter_when_is_hungover(self):
        hangovers = 0

        request.post_vars['drunk_person'] = '1'
        hungover_response = im_hungover()

        hangover_rows = db().select(db.hangover.counter, orderby=~db.hangover.id, limitby=(0,1))
        new_hangovers = hangover_rows[0].counter

        self.assertEquals(hangovers + 1, new_hangovers)

    def test_return_405_when_get_im_hungover_url(self):
        request.post_vars.pop('drunk_person')
        hungover_response = im_hungover()
        self.assertEquals(405, hungover_response.status)

    def test_counter_return_hangovers_when_db_has_wors(self):
        request.post_vars['drunk_person'] = '1'
        hungover_response = im_hungover()

        request.post_vars.pop('drunk_person')
        index_response = index()
        self.assertEquals(1, index_response['counter'])

suite = unittest.TestSuite()
suite.addTest(unittest.makeSuite(TestCounter))
unittest.TextTestRunner(verbosity=2).run(suite)

